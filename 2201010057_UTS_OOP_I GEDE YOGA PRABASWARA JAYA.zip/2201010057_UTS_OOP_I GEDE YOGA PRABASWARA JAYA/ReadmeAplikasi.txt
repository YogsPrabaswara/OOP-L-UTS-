Kelas : Aplikasi 

Metode : 
main(String[] args) - Titik awal program aplikasi 

Penjelasan : 
- Kelas Aplikasi menggunakan kelas CatatBarang untuk mengelola data barang 
- Kelas Aplikasi membuat objek CatatBarang Bernama CaBar untuk melakukan operasi terhadap data barang 
- Kelas Aplikasi tidak memiliki atribut 
- Kelas Aplikasi hanya memiliki satu metode, yaitu main()
- Di dalam metode main(), objek CatatBarang CaBar dibuat dan digunakan untuk melakukan berbagai operasi terhadap data barang 
- Operasi yang dilakukan meliputi : 
	- Menampilkan daftar data barang 
	- Menampilkan data barang baru 
	- Memperbarui data barang 
	- Menghapus data barang
- Kelas Aplikasi menggunakan loop do-while untuk terus menjalankan program hingga user memilih untuk keluar 